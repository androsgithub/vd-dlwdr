const express = require('express');
const cors = require('cors');
const ytdl = require('ytdl-core');
const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

app.post('/download', async (req, res) => {
  try {
    const { videoUrl } = req.body;

    if (!videoUrl) {
      return res.status(400).json({ error: 'Video URL is required' });
    }

    const info = await ytdl.getInfo(videoUrl);
    const videoFormat = ytdl.chooseFormat(info.formats, { quality: 'highestvideo' });
    const audioFormat = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });

    const videoStream = ytdl(videoUrl, { format: videoFormat });
    const audioStream = ytdl(videoUrl, { format: audioFormat });

    const videoPath = 'tempVideo.mp4';
    const audioPath = 'tempAudio.aac';

    const videoFile = fs.createWriteStream(videoPath);
    const audioFile = fs.createWriteStream(audioPath);

    // Pipe streams to files and wait for completion
    await new Promise((resolve, reject) => {
      videoStream.pipe(videoFile);
      videoFile.on('finish', resolve);
      videoFile.on('error', reject);
    });

    await new Promise((resolve, reject) => {
      audioStream.pipe(audioFile);
      audioFile.on('finish', resolve);
      audioFile.on('error', reject);
    });

    // Combine video and audio using FFmpeg
    ffmpeg()
      .input(videoPath)
      .input(audioPath)
      .videoCodec('copy')
      .audioCodec('aac')
      .on('end', () => {
        res.header('Content-Disposition', `attachment; filename="${info.title}.mp4"`);
        const fileStream = fs.createReadStream('output.mp4');
        fileStream.pipe(res);
      })
      .on('error', (err) => {
        console.error('Error during ffmpeg processing:', err);
        res.status(500).json({ error: 'Internal Server Error' });
      })
      .save('output.mp4');
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
